# 12. Which Linear Regression training algorithm can we use if we have a training set with millions of features?
# ANS:
You could use batch gradient descent, stochastic gradient descent, or mini-batch gradient descent. SGD and MBGD would work the best because neuther of them need to load the entire dataset into memory in order to take 1 step of gradient descent. batch would be fine with the caveat that you have enough memory to load all the data.


## 13. Which algorithms will not suffer or might suffer, if the features in training set have very different scales?
# ANS: